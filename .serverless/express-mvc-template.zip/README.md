# express-mvc-template

API /api/property/add

API /api/property/search

Swagger: 

API url:

Assumptions: 
1. case insensitive partial search by suburb, passing other filter won't have any affect
2. have to pass the desired format to pass validator
3. search nothing returns all